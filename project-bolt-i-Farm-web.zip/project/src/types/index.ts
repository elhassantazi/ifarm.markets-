export interface User {
  id: string;
  email: string;
  full_name: string;
  wallet_balance: number;
  created_at: string;
}

export interface Farm {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
  };
  farmer_id: string;
  farmer_rating: number;
  farmer_experience: number;
}

export interface Animal {
  id: string;
  farm_id: string;
  type: 'cattle' | 'poultry' | 'dairy';
  registration_number: string;
  total_shares: number;
  share_price: number;
  available_shares: number;
  cycle_end_date: string;
  expected_return: number;
  current_weight?: number;
  milk_production?: number;
  status: 'active' | 'completed' | 'cancelled';
}

export interface Investment {
  id: string;
  user_id: string;
  animal_id: string;
  shares_count: number;
  purchase_price: number;
  purchase_date: string;
  status: 'active' | 'sold';
  profit_loss?: number;
}