import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Filter, ChevronDown, Users, Clock, TrendingUp } from 'lucide-react';

interface Project {
  id: string;
  name: string;
  farmer: string;
  description: string;
  type: 'elevage' | 'maraichage' | 'arboriculture';
  image: string;
  amountTarget: number;
  amountCollected: number;
  duration: number;
  yield: number;
  location: string;
}

const Investment = () => {
  const [selectedType, setSelectedType] = useState<string>('');
  const [minYield, setMinYield] = useState<number>(0);
  const [maxAmount, setMaxAmount] = useState<number>(1000000);
  const [sortBy, setSortBy] = useState<string>('progress');

  // Exemple de données (à remplacer par l'API)
  const projects: Project[] = [
    {
      id: '1',
      name: 'Élevage bovin laitier bio',
      farmer: 'Mohammed Alami',
      description: "Développement d'un élevage de 50 vaches laitières en agriculture biologique avec transformation fromagère.",
      type: 'elevage',
      image: 'https://images.unsplash.com/photo-1500595046743-cd271d694d30?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80',
      amountTarget: 800000,
      amountCollected: 560000,
      duration: 24,
      yield: 7,
      location: 'Région de Fès-Meknès'
    },
    {
      id: '2',
      name: 'Maraîchage agroécologique',
      farmer: 'Fatima Zahra Bennani',
      description: "Culture de légumes bio sur 5 hectares avec système d'irrigation goutte-à-goutte.",
      type: 'maraichage',
      image: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80',
      amountTarget: 400000,
      amountCollected: 280000,
      duration: 18,
      yield: 8,
      location: 'Région de Rabat-Salé-Kénitra'
    },
    {
      id: '3',
      name: 'Verger d\'oliviers traditionnel',
      farmer: 'Ahmed Tazi',
      description: "Extension d'un verger familial de 10 hectares pour la production d'huile d'olive extra vierge.",
      type: 'arboriculture',
      image: 'https://images.unsplash.com/photo-1508767887031-185bbeb45718?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80',
      amountTarget: 600000,
      amountCollected: 420000,
      duration: 36,
      yield: 6.5,
      location: 'Région de Marrakech-Safi'
    }
  ];

  const filteredProjects = projects
    .filter(project => !selectedType || project.type === selectedType)
    .filter(project => project.yield >= minYield)
    .filter(project => project.amountTarget <= maxAmount)
    .sort((a, b) => {
      switch (sortBy) {
        case 'progress':
          return (b.amountCollected / b.amountTarget) - (a.amountCollected / a.amountTarget);
        case 'yield':
          return b.yield - a.yield;
        case 'amount':
          return b.amountTarget - a.amountTarget;
        default:
          return 0;
      }
    });

  return (
    <div className="max-w-7xl mx-auto">
      {/* En-tête et filtres */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Projets à financer</h1>
            <p className="text-gray-600">Découvrez des projets agricoles durables et à impact positif</p>
          </div>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 pr-8 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="progress">Progression</option>
                <option value="yield">Rendement</option>
                <option value="amount">Montant</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none h-5 w-5" />
            </div>
            <button
              onClick={() => {
                setSelectedType('');
                setMinYield(0);
                setMaxAmount(1000000);
                setSortBy('progress');
              }}
              className="flex items-center gap-2 px-4 py-2 text-gray-600 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <Filter className="h-5 w-5" />
              <span>Réinitialiser</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type de production
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-lg px-4 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">Tous les types</option>
              <option value="elevage">Élevage</option>
              <option value="maraichage">Maraîchage</option>
              <option value="arboriculture">Arboriculture</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Rendement minimum
            </label>
            <input
              type="range"
              min="0"
              max="10"
              step="0.5"
              value={minYield}
              onChange={(e) => setMinYield(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-sm text-gray-600 mt-1">
              {minYield}% et plus
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Montant maximum
            </label>
            <input
              type="range"
              min="100000"
              max="1000000"
              step="100000"
              value={maxAmount}
              onChange={(e) => setMaxAmount(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-sm text-gray-600 mt-1">
              Jusqu'à {maxAmount.toLocaleString()} MAD
            </div>
          </div>
        </div>
      </div>

      {/* Grille des projets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project) => (
          <div key={project.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
            <div className="relative h-48">
              <img
                src={project.image}
                alt={project.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-sm font-medium">
                {project.location}
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {project.name}
              </h3>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                {project.description}
              </p>
              
              <div className="flex items-center gap-2 text-gray-600 text-sm mb-4">
                <Users className="h-4 w-4" />
                <span>{project.farmer}</span>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Progression</span>
                    <span>{Math.round((project.amountCollected / project.amountTarget) * 100)}%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${(project.amountCollected / project.amountTarget) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="font-medium">{project.amountCollected.toLocaleString()} MAD</span>
                    <span className="text-gray-500">sur {project.amountTarget.toLocaleString()} MAD</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 py-4 border-t border-gray-100">
                  <div className="text-center">
                    <div className="flex items-center justify-center text-primary mb-1">
                      <TrendingUp className="h-4 w-4" />
                    </div>
                    <div className="text-lg font-bold">{project.yield}%</div>
                    <div className="text-xs text-gray-500">Rendement</div>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center text-primary mb-1">
                      <Clock className="h-4 w-4" />
                    </div>
                    <div className="text-lg font-bold">{project.duration}</div>
                    <div className="text-xs text-gray-500">Mois</div>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center text-primary mb-1">
                      <Users className="h-4 w-4" />
                    </div>
                    <div className="text-lg font-bold">127</div>
                    <div className="text-xs text-gray-500">Investisseurs</div>
                  </div>
                </div>

                <Link
                  to={`/project/${project.id}`}
                  className="block w-full text-center py-3 px-4 bg-primary text-white font-medium rounded-lg hover:bg-primary-dark transition-colors"
                >
                  Découvrir le projet
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Investment;