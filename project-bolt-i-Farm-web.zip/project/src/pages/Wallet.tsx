import React, { useState } from 'react';
import { Wallet as WalletIcon, ArrowUpRight, ArrowDownRight, History, X, CreditCard, Building2, Smartphone, Banknote } from 'lucide-react';

interface Investment {
  id: string;
  animalId: string;
  matricule: string;
  type: 'cattle' | 'poultry' | 'dairy';
  shares: number;
  purchasePrice: number;
  currentPrice: number;
  profit: number;
  status: 'active' | 'selling' | 'sold';
}

const Wallet = () => {
  const [showRechargeModal, setShowRechargeModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showSellModal, setShowSellModal] = useState(false);
  const [selectedInvestment, setSelectedInvestment] = useState<Investment | null>(null);
  const [sellQuantity, setSellQuantity] = useState(1);
  const [sellPrice, setSellPrice] = useState(0);
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('');
  const [bankInfo, setBankInfo] = useState({
    accountHolder: '',
    bankName: '',
    rib: ''
  });

  // Exemple de données (à remplacer par les données de l'API)
  const investments: Investment[] = [
    {
      id: '1',
      animalId: 'V-1432',
      matricule: 'V-1432',
      type: 'cattle',
      shares: 5,
      purchasePrice: 500,
      currentPrice: 550,
      profit: 10,
      status: 'active'
    },
    {
      id: '2',
      animalId: 'L-789',
      matricule: 'L-789',
      type: 'dairy',
      shares: 3,
      purchasePrice: 480,
      currentPrice: 470,
      profit: -2.1,
      status: 'selling'
    },
    {
      id: '3',
      animalId: 'P-456',
      matricule: 'P-456',
      type: 'poultry',
      shares: 2,
      purchasePrice: 490,
      currentPrice: 530,
      profit: 8.2,
      status: 'active'
    }
  ];

  const handleSell = () => {
    if (!selectedInvestment) return;
    // TODO: Implement sell logic
    console.log('Selling investment:', {
      investment: selectedInvestment,
      quantity: sellQuantity,
      price: sellPrice
    });
    setShowSellModal(false);
  };

  const handleCancelSell = (investment: Investment) => {
    // TODO: Implement cancel sell logic
    console.log('Canceling sell order for investment:', investment);
  };

  const handleRecharge = () => {
    // TODO: Implement recharge logic
    setShowRechargeModal(false);
  };

  const handleWithdraw = () => {
    // TODO: Implement withdrawal logic
    setShowWithdrawModal(false);
  };

  const availableBalance = 5000;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm p-8 mb-6">
        <div className="flex items-center space-x-4 mb-6">
          <div className="bg-green-100 p-3 rounded-full">
            <WalletIcon className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Mon Portefeuille</h1>
            <p className="text-gray-600">Gérez vos transactions et votre solde</p>
          </div>
        </div>

        <div className="text-3xl font-bold text-gray-900 mb-2">
          {availableBalance} DHS
        </div>
        <p className="text-gray-500">Solde disponible</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
          <button 
            onClick={() => setShowRechargeModal(true)} 
            className="btn-primary flex items-center justify-center space-x-2"
          >
            <ArrowUpRight className="h-5 w-5" />
            <span>Recharger</span>
          </button>
          <button 
            onClick={() => setShowWithdrawModal(true)}
            className="btn-secondary flex items-center justify-center space-x-2"
          >
            <ArrowDownRight className="h-5 w-5" />
            <span>Retirer</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
        <div className="flex items-center space-x-2 mb-6">
          <History className="h-5 w-5 text-gray-500" />
          <h2 className="text-xl font-semibold">Mes Investissements</h2>
        </div>

        <div className="space-y-4">
          {investments.map((investment) => (
            <div key={investment.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="flex items-center gap-4 mb-1">
                  <span className="text-lg font-semibold">{investment.matricule}</span>
                  <span className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                    {investment.type === 'cattle' ? 'Bovin' :
                     investment.type === 'poultry' ? 'Volaille' : 'Vache laitière'}
                  </span>
                  {investment.status === 'selling' && (
                    <span className="px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-sm">
                      En vente
                    </span>
                  )}
                </div>
                <div className="text-gray-600">
                  {investment.shares} actions • Prix d'achat: {investment.purchasePrice} DHS
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-lg font-semibold">{investment.currentPrice} DHS</div>
                  <div className={`text-sm ${investment.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {investment.profit >= 0 ? '+' : ''}{investment.profit}%
                  </div>
                </div>
                <div className="w-[180px]">
                  {investment.status === 'selling' ? (
                    <button
                      onClick={() => handleCancelSell(investment)}
                      className="w-full px-6 py-3 bg-red-100 text-red-600 font-medium rounded-xl hover:bg-red-200 transition-all duration-300 flex items-center justify-center"
                    >
                      <span>Annuler Ordre</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setSelectedInvestment(investment);
                        setSellPrice(investment.currentPrice * 0.98);
                        setSellQuantity(1);
                        setShowSellModal(true);
                      }}
                      className="w-full group relative overflow-hidden bg-red-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-red-700 transition-all duration-300 shadow-lg hover:shadow-xl"
                    >
                      <div className="absolute inset-0 w-3/12 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[30deg] group-hover:-translate-x-[200%] transition-transform duration-1000 ease-in-out" />
                      <div className="flex items-center justify-center gap-3">
                        <span className="text-lg">Vendre</span>
                        <span className="px-3 py-1 bg-white/20 rounded-lg">
                          {Math.round(investment.currentPrice * 0.98)} DHS
                        </span>
                      </div>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sell Modal */}
      {showSellModal && selectedInvestment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl max-w-md w-full mx-4 p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">Vendre des actions</h2>
              <button 
                onClick={() => setShowSellModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-lg font-semibold">{selectedInvestment.matricule}</span>
                  <span className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                    {selectedInvestment.type === 'cattle' ? 'Bovin' :
                     selectedInvestment.type === 'poultry' ? 'Volaille' : 'Vache laitière'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nombre d'actions à vendre
                    </label>
                    <input
                      type="number"
                      value={sellQuantity}
                      onChange={(e) => setSellQuantity(Math.min(Number(e.target.value), selectedInvestment.shares))}
                      min="1"
                      max={selectedInvestment.shares}
                      className="input-field"
                      required
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      Maximum: {selectedInvestment.shares} actions
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Prix par action (DHS)
                    </label>
                    <input
                      type="number"
                      value={sellPrice}
                      onChange={(e) => setSellPrice(Number(e.target.value))}
                      min="0"
                      className="input-field"
                      required
                    />
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Total de la vente</span>
                    <span className="font-semibold">{sellPrice * sellQuantity} DHS</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Prix d'achat moyen</span>
                    <span className="font-semibold">{selectedInvestment.purchasePrice} DHS</span>
                  </div>
                </div>
              </div>

              <button 
                onClick={handleSell}
                className="w-full py-3 px-4 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
              >
                Confirmer la vente
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Recharge Modal */}
      {showRechargeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl max-w-md w-full mx-4 p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">Recharger mon compte</h2>
              <button 
                onClick={() => setShowRechargeModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Montant à recharger (DHS)
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="input-field"
                  placeholder="1000"
                  min="100"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Méthode de paiement
                </label>
                <div className="grid grid-cols-1 gap-3">
                  <PaymentMethodButton
                    icon={<CreditCard className="h-5 w-5" />}
                    title="Carte bancaire"
                    description="Paiement sécurisé par CMI"
                    selected={selectedMethod === 'card'}
                    onClick={() => setSelectedMethod('card')}
                  />
                  <PaymentMethodButton
                    icon={<Building2 className="h-5 w-5" />}
                    title="Virement bancaire"
                    description="Recevez les coordonnées bancaires"
                    selected={selectedMethod === 'transfer'}
                    onClick={() => setSelectedMethod('transfer')}
                  />
                  <PaymentMethodButton
                    icon={<Banknote className="h-5 w-5" />}
                    title="Agence de cash"
                    description="Wafacash, Cash Plus, etc."
                    selected={selectedMethod === 'cash'}
                    onClick={() => setSelectedMethod('cash')}
                  />
                  <PaymentMethodButton
                    icon={<Smartphone className="h-5 w-5" />}
                    title="Application bancaire"
                    description="Recevez une référence de paiement"
                    selected={selectedMethod === 'app'}
                    onClick={() => setSelectedMethod('app')}
                  />
                </div>
              </div>

              <button 
                onClick={handleRecharge}
                disabled={!amount || !selectedMethod}
                className={`w-full py-3 px-4 rounded-lg font-medium text-white ${
                  amount && selectedMethod 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-gray-300 cursor-not-allowed'
                }`}
              >
                Continuer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Withdraw Modal */}
      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl max-w-md w-full mx-4 p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">Retirer des fonds</h2>
              <button 
                onClick={() => setShowWithdrawModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Montant à retirer (DHS)
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="input-field"
                  placeholder="1000"
                  min="100"
                  max={availableBalance}
                  required
                />
                <p className="text-sm text-gray-500 mt-1">
                  Solde disponible: {availableBalance} DHS
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Méthode de retrait
                </label>
                <div className="grid grid-cols-1 gap-3">
                  <PaymentMethodButton
                    icon={<Building2 className="h-5 w-5" />}
                    title="Virement bancaire"
                    description="2-3 jours ouvrables"
                    selected={selectedMethod === 'bank'}
                    onClick={() => setSelectedMethod('bank')}
                  />
                  <PaymentMethodButton
                    icon={<Banknote className="h-5 w-5" />}
                    title="Agence de cash"
                    description="Retrait immédiat avec code"
                    selected={selectedMethod === 'cash'}
                    onClick={() => setSelectedMethod('cash')}
                  />
                </div>
              </div>

              {selectedMethod === 'bank' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Titulaire du compte
                    </label>
                    <input
                      type="text"
                      value={bankInfo.accountHolder}
                      onChange={(e) => setBankInfo({...bankInfo, accountHolder: e.target.value})}
                      className="input-field"
                      placeholder="Nom complet"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Banque
                    </label>
                    <input
                      type="text"
                      value={bankInfo.bankName}
                      onChange={(e) => setBankInfo({...bankInfo, bankName: e.target.value})}
                      className="input-field"
                      placeholder="Nom de la banque"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      RIB
                    </label>
                    <input
                      type="text"
                      value={bankInfo.rib}
                      onChange={(e) => setBankInfo({...bankInfo, rib: e.target.value})}
                      className="input-field"
                      placeholder="24 chiffres"
                      maxLength={24}
                      required
                    />
                  </div>
                </div>
              )}

              <button 
                onClick={handleWithdraw}
                disabled={!amount || !selectedMethod || (selectedMethod === 'bank' && (!bankInfo.accountHolder || !bankInfo.bankName || !bankInfo.rib))}
                className={`w-full py-3 px-4 rounded-lg font-medium text-white ${
                  amount && selectedMethod && (selectedMethod !== 'bank' || (bankInfo.accountHolder && bankInfo.bankName && bankInfo.rib))
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-gray-300 cursor-not-allowed'
                }`}
              >
                Confirmer le retrait
              </button>

              <p className="text-sm text-gray-500 text-center">
                {selectedMethod === 'bank' 
                  ? 'Le virement sera effectué sous 2-3 jours ouvrables'
                  : selectedMethod === 'cash'
                  ? 'Vous recevrez un code par SMS pour retirer en agence'
                  : ''}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const PaymentMethodButton = ({ icon, title, description, selected, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-4 p-4 rounded-lg border-2 text-left transition-colors ${
      selected 
        ? 'border-green-600 bg-green-50' 
        : 'border-gray-200 hover:border-gray-300'
    }`}
  >
    <div className={`${selected ? 'text-green-600' : 'text-gray-500'}`}>
      {icon}
    </div>
    <div>
      <div className="font-medium">{title}</div>
      <div className="text-sm text-gray-500">{description}</div>
    </div>
  </button>
);

export default Wallet;