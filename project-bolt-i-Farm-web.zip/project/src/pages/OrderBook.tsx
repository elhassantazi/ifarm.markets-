import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';

interface Order {
  id: string;
  animalId: string;
  animalType: 'cattle' | 'poultry' | 'dairy';
  matricule: string;
  price: number;
  quantity: number;
  date: string;
  status: 'active' | 'filled' | 'cancelled';
}

const OrderBook = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);

  // Exemple de données (à remplacer par les données de l'API)
  const orders: Order[] = [
    {
      id: '1',
      animalId: '1',
      animalType: 'cattle',
      matricule: 'V-1432',
      price: 515,
      quantity: 2,
      date: '2024-03-15T11:15:00',
      status: 'active'
    },
    {
      id: '2',
      animalId: '2',
      animalType: 'dairy',
      matricule: 'L-789',
      price: 520,
      quantity: 4,
      date: '2024-03-15T09:45:00',
      status: 'active'
    },
    {
      id: '3',
      animalId: '3',
      animalType: 'poultry',
      matricule: 'P-456',
      price: 525,
      quantity: 1,
      date: '2024-03-15T10:30:00',
      status: 'active'
    }
  ];

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.matricule.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedTypes.length === 0 || selectedTypes.includes(order.animalType);
    const matchesPrice = order.price >= priceRange[0] && order.price <= priceRange[1];
    return matchesSearch && matchesType && matchesPrice;
  });

  const handleBuy = (order: Order) => {
    // TODO: Implement buy logic
    console.log('Buying order:', order);
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Actions disponibles à la vente</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Rechercher par matricule..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          <div className="flex gap-2">
            <input
              type="number"
              placeholder="Prix min"
              value={priceRange[0]}
              onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
            <input
              type="number"
              placeholder="Prix max"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedTypes([]);
              setPriceRange([0, 1000]);
            }}
            className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Réinitialiser les filtres
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm divide-y">
        {filteredOrders.map((order) => (
          <div key={order.id} className="p-6 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-4 mb-2">
                <span className="text-lg font-semibold">{order.matricule}</span>
                <span className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                  {order.animalType === 'cattle' ? 'Bovin' :
                   order.animalType === 'poultry' ? 'Volaille' : 'Vache laitière'}
                </span>
              </div>
              <div className="text-gray-500 text-sm">
                {new Date(order.date).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'long',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
            </div>
            
            <div className="flex items-center gap-8">
              <div className="text-right">
                <div className="text-2xl font-bold text-gray-900">{order.price} DHS</div>
                <div className="text-gray-500">{order.quantity} actions</div>
              </div>
              
              <button
                onClick={() => handleBuy(order)}
                className="group relative overflow-hidden bg-green-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-green-700 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <div className="absolute inset-0 w-3/12 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[30deg] group-hover:-translate-x-[200%] transition-transform duration-1000 ease-in-out" />
                <div className="flex items-center gap-3">
                  <span className="text-lg">Acheter</span>
                  <span className="px-3 py-1 bg-white/20 rounded-lg">
                    {order.price} DHS
                  </span>
                </div>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrderBook;