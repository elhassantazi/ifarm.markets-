import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bird, Droplets, Star, X, Filter, Check } from 'lucide-react';
import Logo from '../components/Logo';

interface Animal {
  id: string;
  type: 'cattle' | 'poultry' | 'dairy';
  matricule: string;
  position: { x: number; y: number };
  price: number;
  shares: number;
  sharePrice: number;
  weight?: number;
  expectedWeight?: number;
  milkProduction?: number;
  expectedReturn: number;
  cycleEndDate: string;
  farmerRating: number;
  farmerExperience: number;
}

const MarketMap = () => {
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [showOrderBook, setShowOrderBook] = useState(false);
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [buyQuantity, setBuyQuantity] = useState(1);

  // Sample data
  const animals: Animal[] = [
    {
      id: '1',
      type: 'cattle',
      matricule: 'V-1432',
      position: { x: 30, y: 40 },
      price: 30000,
      shares: 60,
      sharePrice: 500,
      weight: 450,
      expectedWeight: 550,
      expectedReturn: 15,
      cycleEndDate: '2024-06-15',
      farmerRating: 4.8,
      farmerExperience: 15
    },
    {
      id: '2',
      type: 'dairy',
      matricule: 'L-789',
      position: { x: 70, y: 30 },
      price: 40000,
      shares: 80,
      sharePrice: 500,
      milkProduction: 25,
      expectedReturn: 12,
      cycleEndDate: '2025-03-15',
      farmerRating: 4.5,
      farmerExperience: 10
    },
    {
      id: '3',
      type: 'poultry',
      matricule: 'P-456',
      position: { x: 50, y: 60 },
      price: 15000,
      shares: 30,
      sharePrice: 500,
      expectedReturn: 18,
      cycleEndDate: '2024-05-01',
      farmerRating: 4.2,
      farmerExperience: 8
    }
  ];

  const filteredAnimals = selectedTypes.length > 0
    ? animals.filter(animal => selectedTypes.includes(animal.type))
    : animals;

  const getAnimalIcon = (type: string) => {
    switch (type) {
      case 'cattle':
        return <Logo className="h-8 w-8" />;
      case 'poultry':
        return <Bird className="h-8 w-8" />;
      case 'dairy':
        return <Droplets className="h-8 w-8" />;
      default:
        return null;
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const toggleType = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type)
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const handleBuy = () => {
    setShowBuyModal(true);
  };

  const confirmBuy = () => {
    setShowBuyModal(false);
    setShowConfirmation(true);
    setTimeout(() => {
      setShowConfirmation(false);
      setSelectedAnimal(null);
    }, 2000);
  };

  return (
    <div className="h-[calc(100vh-6rem)]">
      <div className="bg-white rounded-xl shadow-sm p-6 mb-4">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Carte des Opportunités</h1>
            <p className="text-gray-600">Explorez les opportunités d'investissement disponibles</p>
          </div>
          <div className="flex gap-2">
            <FilterButton
              type="cattle"
              label="Bovins"
              icon={<Logo className="h-5 w-5" />}
              isSelected={selectedTypes.includes('cattle')}
              onClick={() => toggleType('cattle')}
            />
            <FilterButton
              type="dairy"
              label="Laitier"
              icon={<Droplets className="h-5 w-5" />}
              isSelected={selectedTypes.includes('dairy')}
              onClick={() => toggleType('dairy')}
            />
            <FilterButton
              type="poultry"
              label="Volaille"
              icon={<Bird className="h-5 w-5" />}
              isSelected={selectedTypes.includes('poultry')}
              onClick={() => toggleType('poultry')}
            />
            {selectedTypes.length > 0 && (
              <button
                onClick={() => setSelectedTypes([])}
                className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-2"
              >
                <Filter className="h-5 w-5" />
                Tout afficher
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="relative h-[calc(100%-7rem)] bg-gradient-to-b from-primary/10 to-primary/5 rounded-xl overflow-hidden">
        {/* Stylized Landscape Elements */}
        <div className="absolute inset-0">
          <div className="absolute w-full h-full">
            {/* Hills and Landscape Features */}
            <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-primary/20 to-transparent" />
            <div className="absolute bottom-0 left-1/4 w-32 h-32 bg-primary/10 rounded-full transform -translate-x-1/2 translate-y-1/2" />
            <div className="absolute bottom-0 right-1/3 w-48 h-48 bg-primary/15 rounded-full transform translate-y-1/4" />
            <div className="absolute top-1/4 left-1/3 w-24 h-24 bg-primary/10 rounded-full" />
            <div className="absolute top-1/2 right-1/4 w-36 h-36 bg-primary/10 rounded-full" />
          </div>
        </div>

        {/* Investment Opportunities */}
        {filteredAnimals.map((animal) => (
          <motion.button
            key={animal.id}
            style={{
              position: 'absolute',
              left: `${animal.position.x}%`,
              top: `${animal.position.y}%`,
            }}
            whileHover={{ scale: 1.2 }}
            onClick={() => setSelectedAnimal(animal)}
            className="transform -translate-x-1/2 -translate-y-1/2"
          >
            <div className="bg-white p-2 rounded-full shadow-lg">
              <div className={`${
                animal.type === 'cattle' ? 'text-primary' :
                animal.type === 'poultry' ? 'text-orange-500' :
                'text-blue-500'
              }`}>
                {getAnimalIcon(animal.type)}
              </div>
            </div>
          </motion.button>
        ))}

        {/* Selected Animal Details */}
        <AnimatePresence>
          {selectedAnimal && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-4 left-4 right-4 bg-white rounded-xl shadow-lg p-6 max-w-2xl mx-auto"
            >
              <button
                onClick={() => setSelectedAnimal(null)}
                className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="flex items-start gap-4">
                <div className="bg-gray-100 p-3 rounded-lg">
                  {getAnimalIcon(selectedAnimal.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-xl font-bold">
                      {selectedAnimal.type === 'cattle' ? 'Bovin' : 
                       selectedAnimal.type === 'poultry' ? 'Volaille' : 'Vache Laitière'} #{selectedAnimal.matricule}
                    </h2>
                    <div className="flex items-center text-yellow-500">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="ml-1 text-sm">{selectedAnimal.farmerRating}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">
                    Éleveur avec {selectedAnimal.farmerExperience} ans d'expérience
                  </p>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-500">Prix par action</div>
                      <div className="font-semibold">{selectedAnimal.sharePrice} DHS</div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-500">Actions disponibles</div>
                      <div className="font-semibold">{selectedAnimal.shares}</div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-500">Rendement estimé</div>
                      <div className="font-semibold text-primary">+{selectedAnimal.expectedReturn}%</div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-500">Fin de cycle</div>
                      <div className="font-semibold">{formatDate(selectedAnimal.cycleEndDate)}</div>
                    </div>
                  </div>

                  {selectedAnimal.type === 'cattle' && (
                    <div className="mb-6">
                      <div className="flex justify-between text-sm text-gray-600 mb-2">
                        <span>Progression du poids</span>
                        <span>{Math.round((selectedAnimal.weight! / selectedAnimal.expectedWeight!) * 100)}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full">
                        <div
                          className="h-2 bg-primary rounded-full transition-all"
                          style={{ width: `${(selectedAnimal.weight! / selectedAnimal.expectedWeight!) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-sm mt-1">
                        <span>{selectedAnimal.weight} kg</span>
                        <span>{selectedAnimal.expectedWeight} kg</span>
                      </div>
                    </div>
                  )}

                  {selectedAnimal.type === 'dairy' && (
                    <div className="mb-6">
                      <div className="text-sm text-gray-600 mb-2">Production laitière</div>
                      <div className="font-semibold">{selectedAnimal.milkProduction} L/jour</div>
                    </div>
                  )}

                  <div className="flex gap-4">
                    <button
                      onClick={handleBuy}
                      className="flex-1 bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-dark transition-colors"
                    >
                      Investir
                    </button>
                    <button
                      onClick={() => setShowOrderBook(true)}
                      className="flex-1 border-2 border-primary text-primary px-4 py-2 rounded-lg font-medium hover:bg-primary/5 transition-colors"
                    >
                      Voir le carnet d'ordres
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Success Notification */}
        <AnimatePresence>
          {showConfirmation && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-4 right-4 bg-primary text-white px-6 py-4 rounded-xl shadow-lg flex items-center gap-3"
            >
              <Check className="h-6 w-6" />
              <span className="text-lg font-medium">Ordre exécuté avec succès</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Buy Modal */}
        <AnimatePresence>
          {showBuyModal && selectedAnimal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.95 }}
                className="bg-white rounded-xl max-w-md w-full mx-4 p-6"
              >
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">Acheter des actions</h2>
                  <button 
                    onClick={() => setShowBuyModal(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <span className="text-lg font-semibold">{selectedAnimal.matricule}</span>
                      <span className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                        {selectedAnimal.type === 'cattle' ? 'Bovin' :
                         selectedAnimal.type === 'poultry' ? 'Volaille' : 'Vache laitière'}
                      </span>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nombre d'actions à acheter
                      </label>
                      <input
                        type="number"
                        value={buyQuantity}
                        onChange={(e) => setBuyQuantity(Math.min(Number(e.target.value), selectedAnimal.shares))}
                        min="1"
                        max={selectedAnimal.shares}
                        className="input-field"
                        required
                      />
                      <p className="text-sm text-gray-500 mt-1">
                        Maximum: {selectedAnimal.shares} actions
                      </p>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg mt-6">
                      <div className="flex justify-between mb-2">
                        <span className="text-gray-600">Prix par action</span>
                        <span className="font-semibold">{selectedAnimal.sharePrice} DHS</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total à payer</span>
                        <span className="font-semibold">{selectedAnimal.sharePrice * buyQuantity} DHS</span>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={confirmBuy}
                    className="w-full py-3 px-4 bg-primary text-white font-medium rounded-lg hover:bg-primary-dark transition-colors"
                  >
                    Confirmer l'achat
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Order Book Modal */}
        <AnimatePresence>
          {showOrderBook && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.95 }}
                className="bg-white rounded-xl max-w-lg w-full mx-4 p-6"
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-semibold">Carnet d'ordres</h3>
                  <button
                    onClick={() => setShowOrderBook(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-2">Ordres d'achat (BID)</h4>
                    <div className="space-y-2">
                      <OrderBookItem price={485} quantity={3} type="bid" />
                      <OrderBookItem price={480} quantity={5} type="bid" />
                      <OrderBookItem price={475} quantity={2} type="bid" />
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Ordres de vente (ASK)</h4>
                    <div className="space-y-2">
                      <OrderBookItem price={515} quantity={2} type="ask" />
                      <OrderBookItem price={520} quantity={4} type="ask" />
                      <OrderBookItem price={525} quantity={1} type="ask" />
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const FilterButton = ({ type, label, icon, isSelected, onClick }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors ${
      isSelected
        ? 'bg-primary text-white'
        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
    }`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

const OrderBookItem = ({ price, quantity, type }: { price: number; quantity: number; type: 'bid' | 'ask' }) => (
  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
    <div className={`font-medium ${type === 'bid' ? 'text-primary' : 'text-red-600'}`}>
      {price} DHS
    </div>
    <div className="text-gray-600">{quantity} actions</div>
  </div>
);

export default MarketMap;