import React from 'react';
import { BarChart, TrendingUp, Droplets } from 'lucide-react';

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  subtitle: string;
}

interface Investment {
  id: string;
  type: 'cattle' | 'poultry' | 'dairy';
  shares: number;
  value: number;
  profit: number;
}

interface InvestmentCardProps extends Investment {}

const Dashboard = () => {
  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Tableau de Bord</h1>
        <div className="text-green-600 font-semibold text-lg">
          Solde: 5,000 DHS
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          icon={<BarChart className="h-6 w-6" />}
          title="Investissements Actifs"
          value="3"
          subtitle="Total des investissements"
        />
        <StatCard
          icon={<TrendingUp className="h-6 w-6" />}
          title="Rendement Total"
          value="+12.5%"
          subtitle="Depuis le début"
        />
        <StatCard
          icon={<Droplets className="h-6 w-6" />}
          title="Production Laitière"
          value="850L"
          subtitle="Ce mois"
        />
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">Mes Investissements</h2>
        <div className="space-y-4">
          {investments.map((investment) => (
            <InvestmentCard key={investment.id} {...investment} />
          ))}
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, subtitle }) => (
  <div className="bg-white rounded-xl shadow-sm p-6">
    <div className="flex items-center space-x-3 mb-3">
      <div className="text-green-600">{icon}</div>
      <h3 className="font-semibold text-gray-700">{title}</h3>
    </div>
    <div className="text-2xl font-bold text-gray-900">{value}</div>
    <div className="text-sm text-gray-500">{subtitle}</div>
  </div>
);

const InvestmentCard: React.FC<InvestmentCardProps> = ({ type, id, shares, value, profit }) => (
  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
    <div className="flex items-center space-x-4">
      <div className="bg-green-100 p-2 rounded-lg">
        {type === 'cattle' ? '🐄' : type === 'poultry' ? '🐔' : '🥛'}
      </div>
      <div>
        <div className="font-semibold">{id}</div>
        <div className="text-sm text-gray-500">{shares} actions</div>
      </div>
    </div>
    <div className="text-right">
      <div className="font-semibold">{value} DHS</div>
      <div className={`text-sm ${profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
        {profit >= 0 ? '+' : ''}{profit}%
      </div>
    </div>
  </div>
);

const investments: Investment[] = [
  { id: 'V-1432', type: 'cattle', shares: 5, value: 2500, profit: 12.5 },
  { id: 'P-789', type: 'poultry', shares: 3, value: 1500, profit: -2.1 },
  { id: 'D-456', type: 'dairy', shares: 2, value: 1000, profit: 8.3 },
];

export default Dashboard;