import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Users, Shield } from 'lucide-react';
import Logo from '../components/Logo';

const Home = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Investissez dans l'élevage au Maroc
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Making Agriculture Profitable for Everyone
        </p>
        <div className="flex justify-center space-x-4">
          <Link
            to="/register"
            className="bg-primary text-white px-8 py-3 rounded-lg font-semibold hover:bg-primary-dark"
          >
            Commencer maintenant
          </Link>
          <Link
            to="/map"
            className="bg-white text-primary px-8 py-3 rounded-lg font-semibold border-2 border-primary hover:bg-primary/5"
          >
            Explorer la carte
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
        <FeatureCard
          icon={<Logo className="h-8 w-8" />}
          title="Investissement Transparent"
          description="Suivez vos investissements en temps réel avec une transparence totale"
        />
        <FeatureCard
          icon={<TrendingUp className="h-8 w-8" />}
          title="Rendements Attractifs"
          description="Bénéficiez de rendements potentiels élevés dans le secteur agricole"
        />
        <FeatureCard
          icon={<Users className="h-8 w-8" />}
          title="Communauté Engagée"
          description="Rejoignez une communauté d'investisseurs et d'éleveurs passionnés"
        />
        <FeatureCard
          icon={<Shield className="h-8 w-8" />}
          title="Sécurité Garantie"
          description="Vos investissements sont sécurisés et suivis par des experts"
        />
      </div>

      {/* Section Statistiques */}
      <div className="mt-24 bg-white rounded-2xl shadow-sm p-8">
        <h2 className="text-2xl font-bold text-center mb-12">Notre Impact</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <StatCard
            value="1,250+"
            label="Investisseurs actifs"
          />
          <StatCard
            value="150M"
            label="DHS investis"
          />
          <StatCard
            value="450+"
            label="Éleveurs partenaires"
          />
          <StatCard
            value="15%"
            label="Rendement moyen"
          />
        </div>
      </div>

      {/* Section CTA */}
      <div className="mt-24 text-center">
        <h2 className="text-3xl font-bold mb-6">Prêt à commencer ?</h2>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          Rejoignez i-Farm aujourd'hui et participez à la révolution de l'investissement agricole au Maroc.
        </p>
        <Link
          to="/register"
          className="inline-block bg-primary text-white px-8 py-4 rounded-xl font-semibold hover:bg-primary-dark transition-colors"
        >
          Créer un compte gratuitement
        </Link>
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }) => (
  <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
    <div className="text-primary mb-4">{icon}</div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const StatCard = ({ value, label }) => (
  <div className="text-center">
    <div className="text-3xl font-bold text-primary mb-2">{value}</div>
    <div className="text-gray-600">{label}</div>
  </div>
);

export default Home;