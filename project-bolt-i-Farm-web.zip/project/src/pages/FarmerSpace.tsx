import React, { useState } from 'react';
import { Upload, Send } from 'lucide-react';

interface FormData {
  farmerName: string;
  farmName: string;
  contact: string;
  location: string;
  activityType: string;
  amount: string;
  duration: string;
  description: string;
  files: FileList | null;
}

const FarmerSpace = () => {
  const [formData, setFormData] = useState<FormData>({
    farmerName: '',
    farmName: '',
    contact: '',
    location: '',
    activityType: 'elevage',
    amount: '',
    duration: '',
    description: '',
    files: null
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement form submission logic
    console.log('Form data:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFormData(prev => ({
        ...prev,
        files: e.target.files
      }));
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-primary/10 rounded-3xl p-8 md:p-12 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
          Vous êtes agriculteur ? Lancez votre projet !
        </h1>
        <p className="text-lg text-gray-600">
          Notre plateforme vous permet de financer vos projets agricoles grâce au soutien de particuliers. 
          Décrivez votre projet, nous l'étudierons et le rendrons visible à des milliers de contributeurs.
        </p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom de l'agriculteur
              </label>
              <input
                type="text"
                name="farmerName"
                value={formData.farmerName}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom de l'exploitation
              </label>
              <input
                type="text"
                name="farmName"
                value={formData.farmName}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email / Téléphone
              </label>
              <input
                type="text"
                name="contact"
                value={formData.contact}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Localisation du projet
              </label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Type d'activité
              </label>
              <select
                name="activityType"
                value={formData.activityType}
                onChange={handleChange}
                className="input-field"
                required
              >
                <option value="elevage">Élevage</option>
                <option value="maraichage">Maraîchage</option>
                <option value="arboriculture">Arboriculture</option>
                <option value="autre">Autre</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Montant recherché (MAD)
              </label>
              <input
                type="number"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                className="input-field"
                min="10000"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Durée de remboursement souhaitée (mois)
              </label>
              <input
                type="number"
                name="duration"
                value={formData.duration}
                onChange={handleChange}
                className="input-field"
                min="6"
                max="48"
                required
              />
            </div>

            <div className="relative">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Photos du projet
              </label>
              <input
                type="file"
                name="files"
                onChange={handleFileChange}
                multiple
                accept="image/*"
                className="hidden"
                id="files"
              />
              <label
                htmlFor="files"
                className="flex items-center justify-center w-full h-[42px] px-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary transition-colors"
              >
                <Upload className="h-5 w-5 text-gray-400 mr-2" />
                <span className="text-gray-600">Ajouter des photos</span>
              </label>
              {formData.files && (
                <div className="mt-2 text-sm text-gray-600">
                  {formData.files.length} fichier(s) sélectionné(s)
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description du projet
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={6}
              className="input-field"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center space-x-2 bg-primary text-white px-8 py-4 rounded-xl font-semibold hover:bg-primary-dark transition-colors"
          >
            <Send className="h-5 w-5" />
            <span>Soumettre mon projet</span>
          </button>
        </form>
      </div>
    </div>
  );
};

export default FarmerSpace;