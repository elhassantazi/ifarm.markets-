import React from 'react';
import { useParams } from 'react-router-dom';
import { Scale, TrendingUp, Calendar, User } from 'lucide-react';

const AnimalDetails = () => {
  const { id } = useParams();

  // Mock data - will be replaced with real data from API
  const animal = {
    id: 'V-1432',
    type: 'cattle',
    farm: 'Ferme Alami',
    farmer: 'Mohammed Alami',
    farmerRating: 4.8,
    experience: 15,
    totalShares: 10,
    availableShares: 5,
    sharePrice: 500,
    currentWeight: 450,
    expectedWeight: 550,
    cycleEndDate: '2024-06-15',
    expectedReturn: 15,
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm p-8 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Bovin #{animal.id}
            </h1>
            <p className="text-gray-600">
              {animal.farm} • Note: {animal.farmerRating}/5
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">
              {animal.sharePrice} DHS
            </div>
            <div className="text-sm text-gray-500">par action</div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
          <StatItem
            icon={<Scale />}
            label="Poids actuel"
            value={`${animal.currentWeight} kg`}
          />
          <StatItem
            icon={<TrendingUp />}
            label="Rendement estimé"
            value={`${animal.expectedReturn}%`}
          />
          <StatItem
            icon={<Calendar />}
            label="Fin de cycle"
            value="15 Juin 2024"
          />
          <StatItem
            icon={<User />}
            label="Expérience éleveur"
            value={`${animal.experience} ans`}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Acheter des actions</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre d'actions
              </label>
              <input
                type="number"
                min="1"
                max={animal.availableShares}
                className="input-field"
                placeholder="1"
              />
              <p className="text-sm text-gray-500 mt-1">
                {animal.availableShares} actions disponibles
              </p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Total à payer
              </label>
              <div className="text-2xl font-bold text-gray-900">
                500 DHS
              </div>
            </div>
            <button className="btn-primary w-full">
              Confirmer l'achat
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Performance</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Poids initial</span>
              <span className="font-semibold">380 kg</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Poids actuel</span>
              <span className="font-semibold">450 kg</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Poids cible</span>
              <span className="font-semibold">550 kg</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full">
              <div
                className="h-2 bg-green-600 rounded-full"
                style={{ width: '60%' }}
              ></div>
            </div>
            <p className="text-sm text-gray-500 text-center">
              60% de l'objectif atteint
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatItem = ({ icon, label, value }) => (
  <div className="text-center">
    <div className="text-green-600 flex justify-center mb-2">{icon}</div>
    <div className="text-sm text-gray-500 mb-1">{label}</div>
    <div className="font-semibold">{value}</div>
  </div>
);

export default AnimalDetails;