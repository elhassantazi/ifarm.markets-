import React from 'react';
import { Link } from 'react-router-dom';
import { Wallet, LayoutDashboard, LogOut, BookOpen, Sprout, PlusCircle } from 'lucide-react';
import Logo from './Logo';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Logo className="h-8 w-8 text-primary" />
            <div className="flex flex-col">
              <span className="text-xl font-bold text-primary">i-Farm</span>
              <span className="text-xs text-gray-500">Making Agriculture Profitable for Everyone</span>
            </div>
          </Link>
          
          <div className="flex items-center space-x-6">
            <Link to="/investment" className="nav-link">
              <Sprout className="h-5 w-5" />
              <span>Investissement</span>
            </Link>
            <Link to="/dashboard" className="nav-link">
              <LayoutDashboard className="h-5 w-5" />
              <span>Tableau de bord</span>
            </Link>
            <Link to="/orderbook" className="nav-link">
              <BookOpen className="h-5 w-5" />
              <span>Carnet d'ordres</span>
            </Link>
            <Link to="/wallet" className="nav-link">
              <Wallet className="h-5 w-5" />
              <span>Portefeuille</span>
            </Link>
            <Link 
              to="/farmer" 
              className="flex items-center space-x-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
            >
              <PlusCircle className="h-5 w-5" />
              <span>Proposer un projet</span>
            </Link>
            <button className="flex items-center space-x-1 text-red-500 hover:text-red-600">
              <LogOut className="h-5 w-5" />
              <span>Déconnexion</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;