import React from 'react';

const Logo = ({ className = "h-8 w-8", color = "currentColor" }) => (
  <svg 
    viewBox="0 0 1000 1000" 
    className={className}
    fill={color}
  >
    <path d="M300 200 L150 300 L200 400 L250 700 L350 800 L500 850 L650 800 L750 700 L800 400 L850 300 L700 200 L500 350 L300 200 Z" />
  </svg>
);

export default Logo;